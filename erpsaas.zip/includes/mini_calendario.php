<!-- mini_calendario.php -->

<div class="calendario-pequeno card-painel">
    <h3>Calendário do mês</h3><br>
    <div class="mini-calendar" id="miniCalendar"></div>
    <div class="datas-comemorativas" id="listaDatas"><strong>Comemorativos:</strong><ul id="listaDatas"></ul>
    </div>
</div>
