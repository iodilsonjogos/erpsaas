<nav class="menu-lateral" id="menuLateral">
    <ul>
        <li><a href="#dashboard"><i class="ri-dashboard-line"></i> <span>Dashboard</span></a></li>
        <li><a href="#home"><i class="ri-home-4-line"></i> <span>Home</span></a></li>
        <li><a href="#agenda"><i class="ri-calendar-2-line"></i> <span>Agenda</span></a></li>
        <li><a href="#vendas"><i class="ri-shopping-cart-2-line"></i> <span>Vendas/Caixa</span></a></li>
        <li><a href="#clientes"><i class="ri-group-line"></i> <span>Clientes</span></a></li>
        <li><a href="#profissionais"><i class="ri-user-star-line"></i> <span>Profissionais</span></a></li>
        <li><a href="#produtos"><i class="ri-box-3-line"></i> <span>Produtos</span></a></li>
        <li><a href="#servicos"><i class="ri-scissors-cut-line"></i> <span>Serviços</span></a></li>
        <li><a href="#relatorios"><i class="ri-bar-chart-2-line"></i> <span>Relatórios</span></a></li>
        <li><a href="#financeiro"><i class="ri-coins-line"></i> <span>Financeiro</span></a></li>
        <li><a href="#configuracoes"><i class="ri-settings-3-line"></i> <span>Configurações</span></a></li>
    </ul>
</nav>