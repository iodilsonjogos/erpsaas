<div class="conteudo-agenda">
    <div id="fullcalendar"></div>
</div>
