<!-- includes/fila_espera.php -->

<div class="box fila-espera">
    <div class="fila-espera card-painel" id="box fila-espera">
        <h3>Fila de Espera</h3>
        <br>
        <ul class="lista-fila-rolavel" id="listaFila">
            <li class="lista-fila" id="listaFila"></li>
        </ul>
        <br>
        <button id="btnAddFila" class="btn-icon" title="Adicionar à lista de espera">
            <i class="ri-add-line"></i><i class="ri-list-unordered"></i></button>
    </div>
</div>